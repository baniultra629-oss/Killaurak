package com.example.killaura;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;

public class KillAuraMod implements ClientModInitializer {
    // Настройки
    private static final double RANGE = 4.0;             // радиус в блоках
    private static final boolean ATTACK_PLAYERS = false; // true = бить и игроков
    private static final float MIN_COOLDOWN = 1.0f;      // 1.0 = полный заряд удара

    private static KeyBinding toggleKey;
    private static boolean enabled = false;

    @Override
    public void onInitializeClient() {
        // Клавиша R: включить / выключить (можно поменять в настройках управления)
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.killaura.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.killaura"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        PlayerEntity player = client.player;

        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            if (player != null) {
                player.sendMessage(Text.literal("KillAura: " + (enabled ? "ON" : "OFF")), true);
            }
        }

        if (!enabled) return;
        if (player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;
        if (player.getAttackCooldownProgress(0.5f) < MIN_COOLDOWN) return;

        LivingEntity target = client.world
                .getEntitiesByClass(LivingEntity.class,
                        player.getBoundingBox().expand(RANGE),
                        e -> isValidTarget(player, e))
                .stream()
                .min(Comparator.comparingDouble(player::squaredDistanceTo))
                .orElse(null);

        if (target == null || player.distanceTo(target) > RANGE) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    private boolean isValidTarget(PlayerEntity self, LivingEntity e) {
        if (e == self || !e.isAlive()) return false;
        if (e instanceof HostileEntity) return true;
        return ATTACK_PLAYERS && e instanceof PlayerEntity;
    }
}
